﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace GeoLab100.Models
{
    public class User
    {
        public int EWUid { get; set; }
        public string Name { get; set; }
        public string UserType { get; set; }
        public string Group { get; set; }
        public Lab CurrentLabState { get; set; }
    }
}