﻿/*===============================================================
     * NOTES 
     * 
     * Event Listeners can probably be cleaned up and made
     * to apply to all current and future elements so that there
     * only needs to be one declaration.
     * 
     * Little to no security was implemented with the following 
     * code, it could definitely benefit from research and
     * addition of security measures.
  ===============================================================*/
var numExercises = 1;
$(document).ready(function () {
    $('#summernote1').summernote(); // Default method of instantiating an instance of summernote
    var needsSave = false;
    $("#lab-title").val(window.document.title);
    var newTitle = $("#lab-title").val();
    $("#brand-title").html(window.document.title);

    /*=============================================================
     * Event Listener that updates page title, navbar when title is
     * changed. This may be better suited at save instead of real
     * time.
     ==============================================================*/
    $(".title").keyup(function () {
        needsSave = true;
        var newTitle = $("#lab-title").val();
        $("#brand-title").html(newTitle);
        window.document.title = newTitle;
    });

    /*=============================================================
     * Event Listener for creating a new exercise.
     ==============================================================*/
    $("#create-exercise-btn").click(function () {
        numExercises++;
        createNewExercise(numExercises);
        needsSave = true;
    });


    /*=============================================================
     * Event Listener for the save lab button. 
     * - Pulls all content from the page, loads it into the variable labData 
     * - Package labData as JSON and send it to LabController.cs via AJAX
     * 
     * NOTE: This input may need to be sanitized, i.e. something like
     * PHP's htmlspecialchars() so as to prevent XSS or Self-XSS
     * from the instructor.
     ==============================================================*/
    $("#save-lab-btn").click(function () {
        var title = $("#lab-title").val();
        var exerciseTitles = [];
        var exerciseContent = [];
        var exerciseResponse;
        var exerciseMultiOpts = [];
        for (var i = 1; i <= numExercises; i++) {
            var exerciseTitle = $("#ex-title-" + i).val();
            exerciseTitles.push(exerciseTitle);
            var content = $("#summernote" + i).summernote('code');
            exerciseContent.push(content);
            var exerciseResponse = $("#ex-response-" + i).val();
            if (exerciseResponse == 'multi') {
                multi = $("#ex-multi-" + i);
                opts = $(multi).children();
                numOpts = $(opts[opts.length - 1]).attr('name').split('-')[1];
                optValues = [];
                for (var j = 1; j < opts.length; j = j + 2) {
                    optValues.push(opts[j].value);
                }
                exerciseMultiOpts.push(optValues);
            }
        }

        //console.log(title);
        //console.log(exerciseTitles);
        //console.log(exerciseContent);
        //console.log(exerciseResponse);
        //console.log(exerciseMultiOpts);

        var labData = [
            { title: title },
            { exerciseTitles: exerciseTitles },
            { exerciseContent: exerciseContent }
        ];

        labData = JSON.stringify({
            'title': title,
            'exerciseTitles': exerciseTitles,
            'exerciseContent': exerciseContent
        });

        $.ajax({
            contentType: 'application/json; charset=utf-8',

            dataType: 'json',
            type: 'POST',
            url: '../Lab/Save',
            data: labData,
            success: function (response, textStatus, jqHXR) {
                alert("Lab was saved successfully!");
            },
            failure: function (jqHXR, textStatus, errorThrown) {
                console.log("The following errors occurred when saving the lab: " + textStatus, errorThrown);
            }
        });

    });

    $("#preview-lab-btn").click(function() {
        window.open('../Lab/DisplayLab');
    });

    $("#remove-ex-1").click( function(){
        var exId = this.id.split('-');
        var exnum = exId[exId.length - 1];
        numExercises--;
        removeExercise(exnum);
    });

    $("#move-up-ex-1").click(function () {
        var up = true;
        var exId = this.id.split('-');
        var exnum = exId[exId.length - 1];
        moveExercise(exnum, up);
    });

    $("#move-down-ex-1").click(function () {
        var up = false;
        var exId = this.id.split('-');
        var exnum = exId[exId.length - 1];
        moveExercise(exnum, up);
    });

    $("#add-multi-option-1").click(function () {
        multi = $("#ex-multi-1");
        opts = $(multi).children();
        numOpts = $(opts[opts.length - 1]).attr('name').split('-')[1];
        html = "<label>Option " + (++numOpts) + ":</label><input type='text' name='multi-" + numOpts + "'>"; // Use jQuery or detach & clone instead
        $(multi).append(html);
        if (numOpts > 4) // Max of 5 options
            $("#add-multi-option-1").attr("disabled", true);
        if (numOpts > 2) // Min of 2 options (true/false)
            $("#remove-multi-option-1").attr("disabled", false);
    });

    $("#remove-multi-option-1").on('click', function () {
        multi = $("#ex-multi-1");
        opts = $(multi).children();
        numOpts = $(opts[opts.length - 1]).attr('name').split('-')[1];
        opts[opts.length - 1].remove(); // Input
        opts[opts.length - 2].remove(); // Label
        numOpts--;
        if (numOpts < 3) // Min of 2 options (true/false)
            $("#remove-multi-option-1").attr("disabled", true);
        if (numOpts < 5) // Max of 5 options
            $("#add-multi-option-1").attr("disabled", false);
        
    });
}); // Document Ready


/*=============================================================
 * Adds a new exercise to the exercises div, and adds proper
 * event listeners.
 * 
 * TODO: Change this from adding 'raw' html and appending it, to 
 *       jQuery or detaching and cloning an empty exercise. This
 *       will also make it easier to apply changes made to the
 *       lab editor layout or structure.
 ==============================================================*/
function createNewExercise() {
    html = "<div class='row row-relative exercise' id='ex-" + numExercises + "'>";
    html += "<div class='col-sm-1 text-center remove-exercise'>";
    html += "<button class='btn btn-default remove-ex' id='remove-ex-" + numExercises + "'title='Remove Exercise'>Remove</button>";
    html += "</div>";
    $(".exercises").append(html);

    $("#remove-ex-" + numExercises).on('click', function () {
        var exId = this.id.split('-');
        var exnum = exId[exId.length - 1];
        numExercises--;
        removeExercise(exnum);
    });

    html = "<div class='col-sm-10 exercise-content'>";
    html += "<div class='exercise-title'>";
    html += "Exercise Title: <input id='ex-title-" + numExercises + "'type='text'>";
    html += "</div>"; // exerciseTitle

    html += "<div id='summernote" + numExercises + "'></div>";
    html += "<div class='exercise-response-type'>";
    html += "Response:";
    html += "<select id='ex-response-" + numExercises + "' name='responseType'>";
    html += "<option value='short'>Short Answer</option>";
    html += "<option value='long'>Long Answer</option>";
    html += "<option value='multi'>Multiple Choice</option>";
    html += "<option value='img'>Image</option>";
    html += "<option value='vid'>Video</option>";
    html += "</select>";

    html += "<div id='multi-choice-" + numExercises + "' hidden>"; 
    html += "<div class='multi-options' id='ex-multi-" + numExercises + "'>";
    html += "<label>Option 1:</label><input type='text' name='multi-1'>";
    html += "<label>Option 2:</label><input type='text' name='multi-2'>";
    html += "</div>";
    html += "<button class='btn btn-default' id='add-multi-option-" + numExercises + "' title='Create New Multiple Choice'>Add</button>";
    html += "<button class='btn btn-default' id='remove-multi-option-" + numExercises + "' title='Remove Multiple Choice Opt' disabled>Delete</button>";
    html += "</div>";

    html += "</div>"; // exerciseResponseType
    html += "</div>"; // exerciseContent

    html += "<div class='col-sm-1 text-center move'>";
    html += "<button class='btn btn-default' id='move-up-ex-" + numExercises + "' title='Move Exercise Up'>Move Up</button>";
    html += "<button class='btn btn-default' id='move-down-ex-" + numExercises + "' title='Move Exercise Up'>Move Down</button>";
    html += "</div>";

    html += "</div>"; // row

    $("#ex-" + numExercises).append(html);

    $("#move-up-ex-" + numExercises).on('click', function () {
        var up = true;
        var exId = this.id.split('-');
        var exnum = parseInt(exId[exId.length - 1]);
        moveExercise(exnum, up);
    });

    $("#move-down-ex-" + numExercises).on('click', function () {
        var up = false;
        var exId = this.id.split('-');
        var exnum = parseInt(exId[exId.length - 1]);
        moveExercise(exnum, up);
    });

    $('select').on('change', function () {
        var id = $(this).attr('id');
        var exNum = id[id.length - 1];
        if (this.value == "multi")
            $("#multi-choice-" + exNum).show();
        else
            $("#multi-choice-" + exNum).hide();
    });

    $("#add-multi-option-" + numExercises).on('click', function () {
        var exNum = this.parentElement.id.split('-')[2];
        var multi = $("#ex-multi-" + exNum);
        var opts = $(multi).children();
        var numOpts = $(opts[opts.length - 1]).attr('name').split('-')[1];
        var html = "<label>Option " + (++numOpts) + ":</label><input type='text' name='multi-" + numOpts + "'>"; // Use jQuery or detach & clone instead
        $(multi).append(html);
        if (numOpts > 4) // Max of 5 options
            $("#add-multi-option-" + exNum).attr("disabled", true);
        if (numOpts > 2) // Min of 2 options
            $("#remove-multi-option-" + exNum).attr("disabled", false);
    });

    $("#remove-multi-option-" + numExercises).on('click', function () {
        var exNum = this.parentElement.id.split('-')[2];
        var multi = $("#ex-multi-" + exNum);
        var opts = $(multi).children();
        var numOpts = $(opts[opts.length - 1]).attr('name').split('-')[1];
        opts[opts.length - 1].remove();
        opts[opts.length - 2].remove();
        numOpts--;
        if (numOpts < 3) // Min of 2 options
            $("#remove-multi-option-" + exNum).attr("disabled", true);
        if (numOpts < 5) // Max of 5 options
            $("#add-multi-option-" + exNum).attr("disabled", false);
    });

    $("#summernote" + numExercises).summernote(); // Default method of instantiating an instance of summernote
}

$('select').on('change', function () {
    var id = $(this).attr('id');
    var exNum = id[id.length - 1];
    if (this.value == "multi")
        $("#multi-choice-" + exNum).show();
    else
        $("#multi-choice-" + exNum).hide();
});

/*=============================================================
 * Removes an exercise from the exercises div
 * - Destroys the related summernote instance
 * - Adjusts exercise id's so that order is preserved
 ==============================================================*/
function removeExercise(exerciseNum) {
    $('#summernote' + exerciseNum).summernote('destroy');
    $('#ex-' + exerciseNum).remove();
    var exercises = $('.exercises').children();
    var i;
    if (exerciseNum > 1)
        i = exerciseNum - 1;
    else
        i = 0;
    for (i; i < exercises.length; i++) {
        var oldNum = exercises[i].id.split('-')[1]; // I don't like this, but it'll do for now
        exercises[i].id = "ex-" + (i + 1);
        change(oldNum, i + 1);
    }
}

/*=============================================================
 * Moves an exercise in the exercises div
 * - Adjusts affected ids so that order is preserved
 ==============================================================*/
function moveExercise(exercise, up) {
    if (numExercises > 1) {
        if ((exercise > 1) && up) {
            $("#ex-" + exercise).insertBefore("#ex-" + (exercise - 1));
            swap(exercise, exercise - 1);
        }
        else if ((exercise < numExercises) && !up) {
            $("#ex-" + (exercise + 1)).insertBefore("#ex-" + (exercise));
            swap(exercise, exercise + 1);
        }
    }
}

/*=============================================================
 * Change related child id's of ex-oldNum to represent newNum.
 ==============================================================*/
function change(oldNum, newNum) {
    $("#remove-ex-" + oldNum).attr("id", "remove-ex-" + newNum);
    $("#move-up-ex-" + oldNum).attr("id", "move-up-ex-" + newNum);
    $("#move-down-ex-" + oldNum).attr("id", "move-down-ex-" + newNum);
    $("#ex-title-" + oldNum).attr("id", "ex-title-" + newNum);
    $("#summernote" + oldNum).attr("id", "summernote" + newNum);
    $("#ex-response-" + oldNum).attr("id", "ex-response-" + newNum);
    //$("#multi-choice-" + oldNum).attr("id", "multi-choice-" + newNum);
    //$("#ex-multi-" + oldNum).attr("id", "ex-multi-" + newNum);
}

/*=============================================================
 * Swap id's and related child id's of ex1 and ex2.
 ==============================================================*/
function swap(ex1, ex2) {
    var elements = ['#ex-',
        '#remove-ex-',
        '#move-up-ex-',
        '#move-down-ex-',
        '#ex-title-',
        '#summernote',
        '#ex-response-'
        /*,
         * '#multi-choice-',
         * '#ex-multi-'
         */];

    for (var i = 0; i < elements.length; i++) {
        $ex1 = $(elements[i] + ex1);
        $ex2 = $(elements[i] + ex2);
        var temp = $ex1.attr("id");
        $ex1.attr("id", $ex2.attr("id"));
        $ex2.attr("id", temp);
    }
}