﻿/* ==============================================================================*
 *  Drew Scholz - Team 5: Geology - Spring 2017 
 * 
 *  This controller has three Lab model views (Lab Editor, Lab Manager, Display Lab)
 *  and contains methods to:
 *   - import, save, and delete a lab
 *   - connect to the server
 *   - commented methods for saving an image and serializing to a path
 *  
 * ==============================================================================*/

using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Web.Mvc;
using MySQLLibrary;
using MySql.Data.MySqlClient;
using System.Linq;
using System.Xml.Serialization;
using System.Web.Services;

namespace GeoLab100.Controllers
{
    /* ==============================================================================*
     *  This controller has three views
     *   - Lab Editor
     *   - Lab Manager
     *   - Display (rough preview for client demo)
     * ==============================================================================*/
    public class LabController : Controller
    {
        //private Models.Lab lab = new Models.Lab();
        private String isOverriden = "false";
        private String labKey = "Lab1Key"; // with multiple labs this could be changed to the lab's title?

        /* ==============================================================================*
         *  Go to Lab Editor view
         * ==============================================================================*/
        public ActionResult LabEditorView()
        {
            return View("LabEditorView");
        }

        /* ==============================================================================*
         *  Go to Lab Manager view
         * ==============================================================================*/
        public ActionResult LabManagerView()
        {
            return View("LabManagerView");
        }

        /* ==============================================================================*
         *  Import the existing lab under the global lab key
         *      and display 
         * ==============================================================================*/  
        public ActionResult DisplayLab()
        {
            Models.Lab lab = ImportLab();

            return View(lab);
        }

        /* ==============================================================================*
         *  Prints the recieved lab to the console
         *      not currently used but may be useful 
         * ==============================================================================*/
        private void PrintLab(Models.Lab lab)
        {
            Debug.WriteLine(lab.Title);
            
            foreach(Models.Exercise e in lab.ExerciseList)
            {
                Debug.WriteLine(e.ExerciseTitle);
                Debug.WriteLine(e.Content);
            }
        }

        /* ==============================================================================*
         *  Create and serialize Lab model - ajax called from LabEditor.js
         *  then store on server in a parameterized query
         *  under the global labKey
         * ==============================================================================*/
        [HttpPost]
        public ActionResult Save(string title, string[] exerciseTitles, string[] exerciseContent)
        {
            Models.Lab lab = new Models.Lab();
            lab.Title = title;
            /* Lab DueDate will be set from the Lab Manager once it is created
                I left this hear as an example of the expected format 
            */
            //lab.DueDate = new DateTime(2017, 07, 07);
            lab.ExerciseList = new List<Models.Exercise>();

            for (int i = 0; i < exerciseTitles.Length; i++)
            {
                Models.Exercise e = new Models.Exercise();
                e.ExerciseTitle = exerciseTitles[i];
                e.Content = exerciseContent[i];
                //e.ResponseType = exerciseResponseType[i]; // This feature has yet to be implimented
                lab.ExerciseList.Add(e);
            }

            /* Lab is deleted due to overwritting problems
                Another way to solve this problem should eventually be researched
                to lighten the load of server calls
            */
            DeleteLab(); 

            String sql = "USE GEOL100LABS; INSERT INTO Labs(Lab_ID, Content, Is_Overriden) VALUES (@param1, @param2, @param3);";
            String myLab;

            XmlSerializer serializer = new XmlSerializer(lab.GetType());
            using (StringWriter writer = new StringWriter())
            {
                serializer.Serialize(writer, lab);
                myLab = writer.ToString();
            }

            // These 'using' statments are the best practice for iDisposable objects
            using (MySqlConnection connection = ConnectToServer())
            {
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                {
                    // This is the parameterized query style I choose
                    cmd.Parameters.AddWithValue("@param1", labKey);
                    cmd.Parameters.AddWithValue("@param2", myLab);
                    cmd.Parameters.AddWithValue("@param3", isOverriden);

                    cmd.ExecuteNonQuery();
                }
            } 
            return Json("true"); // the content of this return statement is currently irrelevant and can be changed to any string that you want
        }

            /* ==============================================================================*
             *  Retrieve lab from server, deserialize and return as Lab object
             * ==============================================================================*/
         private Models.Lab ImportLab()
         {
            String sql = "USE GEOL100LABS; SELECT * FROM Labs WHERE Lab_ID = @param1 AND Is_Overriden = @param2;";
            String myLab = "";
            Models.Lab lab;

            using (MySqlConnection connection = ConnectToServer())
            {
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                {

                    cmd.Parameters.AddWithValue("@param1", labKey);
                    cmd.Parameters.AddWithValue("@param2", isOverriden);

                    MySqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        myLab = (String)reader["Content"];
                    }
                }
            }

            XmlSerializer serializer = new XmlSerializer(typeof(Models.Lab));
            using (StringReader sReader = new StringReader(myLab))
            {
                lab = (Models.Lab)serializer.Deserialize(sReader);
            }

            return lab;
        }

        /* ==============================================================================*
         *  Delete serialized lab from the server
         * ==============================================================================*/
        private void DeleteLab()
        {
            String sql = "USE GEOL100LABS; DELETE FROM Labs WHERE Lab_ID = @param1 AND Is_Overriden = @param2;";

            using (MySqlConnection connection = ConnectToServer())
            {
                using (MySqlCommand cmd = new MySqlCommand(sql, connection))
                {
                    cmd.Parameters.AddWithValue("@param1", labKey);
                    cmd.Parameters.AddWithValue("@param2", isOverriden);

                    cmd.ExecuteNonQuery();
                }
            }
        }

        /* ==============================================================================* 
         *  Add Lab to server database - username 'bananas' has full access
         * 
         *  username: bananas              
         *  password: zAb7s!agapub          
         * ==============================================================================*/
        private MySqlConnection ConnectToServer()
        {
            MySqlConnection connection = DatabaseUtil.CreateMySqlConnection("146.187.134.39", "bananas", "zAb7s!agapub", database: "");
            return connection;
        }
    }

    /* ==============================================================================*
     *  Commented out methods, saved for potential use only
     * ==============================================================================*/

    /* upload image
    protected void Upload(object sender, EventArgs e)
    {
        if (FileUpload1.HasFile)
        {
            string fileName = Path.GetFileName(FileUpload1.PostedFile.FileName);
            FileUpload1.PostedFile.SaveAs(Server.MapPath("~/Images/") + fileName);
            Response.Redirect(Request.Url.AbsoluteUri);
        }
    } */

    /* display image from folder
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            string[] filePaths = Directory.GetFiles(Server.MapPath("~/Images/"));
            List<ListItem> files = new List<ListItem>();
            foreach (string filePath in filePaths)
            {
                string fileName = Path.GetFileName(filePath);
                files.Add(new ListItem(fileName, "~/Images/" + fileName));
            }
            GridView1.DataSource = files;
            GridView1.DataBind();
        }
    } */

    /* serialize lab to path
    IFormatter formatter = new BinaryFormatter();
    Stream stream = new FileStream(this.path,
                             FileMode.Create,
                             FileAccess.Write, FileShare.None);
    formatter.Serialize(stream, lab);
    stream.Close();
    */


    /* deserialize lab from path into object
    IFormatter formatter = new BinaryFormatter();
    Stream stream = new FileStream(myLab,
                              FileMode.Open,
                              FileAccess.Read,
                              FileShare.Read);
    Models.Lab lab = (Models.Lab)formatter.Deserialize(stream);
    stream.Close();
    */
}